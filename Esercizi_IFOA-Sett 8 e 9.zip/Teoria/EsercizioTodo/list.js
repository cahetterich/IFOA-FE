const todoList = [
    {"08:20": "Portare bimbi a scuola"},
    {"12:20": "Preparare pranzo"},
    {"16:00": "Meeting lavoro"},
]


export { todoList }