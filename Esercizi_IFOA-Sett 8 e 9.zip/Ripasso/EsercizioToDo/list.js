let todoList = [
    {"10:20": "Appuntamento dentista"},
    {"12:30": "Preparare pranzo"},
    {"16:00": "Meeting lavoro"},
]


export { todoList }