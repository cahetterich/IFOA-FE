import Spinner from 'react-bootstrap/Spinner';

function SpinnerWait() {
  return <Spinner animation="grow" />;
}

export default SpinnerWait;